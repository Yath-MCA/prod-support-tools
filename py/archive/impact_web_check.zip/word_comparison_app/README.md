# Word Comparison Tool

A Python-based web application built with Flask for comparing text content against a common-words dictionary.

## Features
- Upload `document_1.txt` and `content.txt`.
- Tokenize and normalize text (lowercase, alphabetic tokens only).
- Calculate total, unique, repeated, and common word counts.
- Generate a premium HTML log-style report.

## How to Run
1. Ensure you have Python installed.
2. Navigate to this directory:
   ```bash
   cd untils_automation/py/word_comparison_app
   ```
3. Install dependencies:
   ```bash
   pip install flask
   ```
4. Start the application:
   ```bash
   python app.py
   ```
5. Open your browser and go to `http://127.0.0.1:5000`.

## Directory Structure
- `app.py`: Backend logic.
- `static/`: Contains `common_words.txt` and `css/style.css`.
- `templates/`: HTML templates for the UI.
- `uploads/`: Temporary storage for uploaded files.
