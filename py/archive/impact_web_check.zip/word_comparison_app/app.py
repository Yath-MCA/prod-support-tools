import os
import re
import json
from collections import Counter
from flask import Flask, render_template, request, redirect, url_for, jsonify
from werkzeug.utils import secure_filename
from bs4 import BeautifulSoup
import requests
import threading
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

app = Flask(__name__)
cache_lock = threading.Lock()

# Configuration
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
STATIC_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
COMMON_WORDS_FILE = os.path.join(STATIC_FOLDER, 'common_words.txt')
CUSTOM_WORDS_FILE = os.path.join(STATIC_FOLDER, 'custom_dictionary.txt')
DICT_CACHE_FILE = os.path.join(STATIC_FOLDER, 'dictionary_cache.json')
# Configuration for Validation Sources
VALIDATION_SOURCES = [
    {
        "id": "primary",
        "name": "FREE DICT",
        "category": "General",
        "url_template": "https://api.dictionaryapi.dev/api/v2/entries/en/{word}",
        "save_file": os.path.join(STATIC_FOLDER, 'verified_primary.txt')
    },
    {
        "id": "wiktionary",
        "name": "Wiktionary",
        "category": "General",
        "url_template": "https://en.wiktionary.org/w/api.php?action=query&titles={word}&format=json",
        "save_file": os.path.join(STATIC_FOLDER, 'verified_wiktionary.txt')
    },
    {
        "id": "secondary",
        "name": "DATAMUSE",
        "category": "General",
        "url_template": "https://api.datamuse.com/words?sp={word}&md=f&max=1",
        "save_file": os.path.join(STATIC_FOLDER, 'verified_secondary.txt')
    },
    {
        "id": "medical",
        "name": "PubChem",
        "category": "Scientific",
        "url_template": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{word}/JSON",
        "save_file": os.path.join(STATIC_FOLDER, 'verified_scientific.txt')
    },
    {
        "id": "biology",
        "name": "GBIF",
        "category": "Scientific",
        "url_template": "https://api.gbif.org/v1/species/match?name={word}",
        "save_file": os.path.join(STATIC_FOLDER, 'verified_scientific.txt')
    }
]

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure folders and files exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
required_files = [CUSTOM_WORDS_FILE, DICT_CACHE_FILE, COMMON_WORDS_FILE]
for src in VALIDATION_SOURCES:
    required_files.append(src['save_file'])

for f_path in required_files:
    if not os.path.exists(f_path):
        with open(f_path, 'w', encoding='utf-8') as f:
            if f_path.endswith('.json'): f.write('{}')
            else: f.write('')

def load_dict_cache():
    try:
        with open(DICT_CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_dict_cache(cache):
    with cache_lock:
        # Re-load latest from disk to avoid overwriting other threads' work
        current_cache = {}
        if os.path.exists(DICT_CACHE_FILE):
            try:
                with open(DICT_CACHE_FILE, 'r', encoding='utf-8') as f:
                    current_cache = json.load(f)
            except: pass
        
        # Add timestamp to incoming entries if they don't have one
        now_iso = datetime.datetime.now().isoformat()
        for word, result in cache.items():
            if "timestamp" not in result:
                result["timestamp"] = now_iso
        
        current_cache.update(cache)
        with open(DICT_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(current_cache, f, indent=4)

def load_common_words():
    ignored = set()
    files_to_load = [COMMON_WORDS_FILE, CUSTOM_WORDS_FILE]
    for src in VALIDATION_SOURCES:
        files_to_load.append(src['save_file'])
        
    for filepath in files_to_load:
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                ignored.update(line.strip().lower() for line in f if line.strip())
    
    # 2. Load from dictionary cache (Ignore anything already checked/validated)
    cache = load_dict_cache()
    for word in cache:
        ignored.add(word.lower())
            
    return ignored

def tokenize(text):
    return re.findall(r'[a-z]+', text.lower())

def extract_body_text(content, file_type):
    parser = 'xml' if file_type == 'xml' else 'html.parser'
    soup = BeautifulSoup(content, parser)
    
    body = None
    if file_type == 'xml':
        # xml => <book-body data-enter-af-fi="yes">
        body = soup.find('book-body')
    elif file_type == 'html':
        # html => <div class="book-body" data-name="book-body">
        body = soup.find('div', class_='book-body')
    
    # Fallback to standard body or whole soup
    if not body:
        body = soup.find('body') or soup

    # Ignore specific classes as requested
    # .ref, .front, .back, and handle nested <ref id="...">
    for tag in body.select('.ref, .front, .back, ref, [class*="ref"], [data-name="ref"], [data-role="ref"]'):
        tag.decompose()
        
    return body.get_text()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    if 'content' not in request.files:
        return redirect(url_for('index'))
    
    content_file = request.files['content']
    
    if content_file.filename == '':
        return redirect(url_for('index'))
    
    # Auto-detect file type from extension
    filename = content_file.filename.lower()
    if filename.endswith('.xml'):
        file_type = 'xml'
    elif filename.endswith(('.html', '.htm')):
        file_type = 'html'
    elif filename.endswith(('.txt', '.log', '.csv')):
        file_type = 'txt'
    else:
        file_type = 'txt' # Default fallback
    
    # Save files temporarily
    content_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(content_file.filename))
    content_file.save(content_path)
    
    # Process content
    with open(content_path, 'r', encoding='utf-8', errors='ignore') as f:
        raw_content = f.read()
    
    if file_type == 'txt':
        clean_text = raw_content
    else:
        # Extract text from specific body tags and ignore classes for HTML/XML
        clean_text = extract_body_text(raw_content, file_type)
    
    words = tokenize(clean_text)
    total_words_count = len(words)
    
    word_counts = Counter(words)
    unique_words_count = len(word_counts)
    
    # Common words matching
    common_words_set = load_common_words()
    common_found = {word: count for word, count in word_counts.items() if word in common_words_set}
    
    # Potential spelling errors (Words NOT in common_words.txt)
    spelling_errors = {word: count for word, count in word_counts.items() if word not in common_words_set}
    
    results = {
        'total_words': total_words_count,
        'unique_words': unique_words_count,
        'unique_error_count': len(spelling_errors),
        'total_error_count': sum(spelling_errors.values()),
        'unique_common_count': len(common_found),
        'total_common_count': sum(common_found.values()),
        'error_list': sorted(spelling_errors.items(), key=lambda x: x[1], reverse=True),
        'common_list': sorted(common_found.items(), key=lambda x: x[1], reverse=True)
    }
    
    return render_template('report.html', results=results)

import requests

def is_common_word_external(word):
    """
    Checks Datamuse API to see if a word is common in English.
    Returns True if the word is found and has a decent frequency.
    """
    try:
        url = f"https://api.datamuse.com/words?sp={word}&md=f&max=1"
        response = requests.get(url, timeout=5).json()
        if response and response[0]['word'].lower() == word.lower():
            tags = response[0].get('tags', [])
            for tag in tags:
                if tag.startswith('f:'):
                    freq = float(tag[2:])
                    # Frequency threshold: > 1.0 is generally common
                    return freq > 1.0
    except Exception:
        pass
    return False

@app.route('/harvest', methods=['POST'])
def harvest():
    words = request.form.getlist('words')
    if not words:
        return redirect(url_for('index'))
    
    unique_words = sorted(list(set(w.lower() for w in words)))
    return render_template('harvest_preview.html', words=unique_words)

@app.route('/api/validate_word', methods=['GET'])
def validate_word():
    word = request.args.get('word', '').strip().lower()
    if not word:
        return {"error": "no word"}, 400
    
    cache = load_dict_cache()
    if word in cache:
        return cache[word]
    
    final_result = {
        "status_code": 404,
        "is_known": False,
        "message": "Not found (Potential Technical Term)",
        "source": None,
        "details": {}
    }
    
    def check_source(src, word):
        try:
            url = src['url_template'].format(word=word)
            resp = requests.get(url, timeout=4)
            if resp.status_code == 200:
                data = resp.json()
                
                # Wiktionary check
                if src['id'] == 'wiktionary':
                    pages = data.get('query', {}).get('pages', {})
                    if "-1" in pages: return None
                
                # Datamuse check
                if src['id'] == 'secondary':
                    if not data or data[0]['word'].lower() != word: return None
                    tags = data[0].get('tags', [])
                    freq = 0
                    for t in tags:
                        if t.startswith('f:'): freq = float(t[2:])
                    if freq <= 0.1: return None
                    return {"src": src, "freq": freq}

                # GBIF check
                if src['id'] == 'biology':
                    if data.get('matchType') == 'NONE' or data.get('confidence', 0) < 90: return None
                
                # PubChem check
                if src['id'] == 'medical':
                    if 'PC_Compounds' not in data: return None

                return {"src": src}
        except:
            return None
        return None

    # Use ThreadPoolExecutor for rapid parallel checks
    with ThreadPoolExecutor(max_workers=len(VALIDATION_SOURCES)) as executor:
        future_to_src = {executor.submit(check_source, src, word): src for src in VALIDATION_SOURCES}
        
        found_result = None
        for future in as_completed(future_to_src):
            res = future.result()
            if res:
                src = res['src']
                final_result["status_code"] = 200
                final_result["is_known"] = True
                final_result["message"] = f"Found ({src['name']})"
                final_result["source"] = src['id']
                final_result["category"] = src['category']
                if "freq" in res:
                    final_result["details"]["frequency"] = res["freq"]
                found_result = final_result
                # We can't easily 'break' the other threads, but we can stop processing results
                break 

    if not found_result:
        found_result = final_result

    # Save to cache immediately to share with other threads
    save_dict_cache({word: found_result})
    return found_result

@app.route('/save_verified', methods=['POST'])
def save_verified():
    words = request.form.getlist('words')
    target_id = request.form.get('target', 'primary')
    
    if not words:
        return jsonify({"success": False, "message": "No words provided"}), 400
    
    # Matching target to source file from config
    target_file = None
    for src in VALIDATION_SOURCES:
        if src['id'] == target_id:
            target_file = src['save_file']
            break
            
    if not target_file:
        return jsonify({"success": False, "message": "Invalid target"}), 400
    
    existing = set()
    if os.path.exists(target_file):
        with open(target_file, 'r', encoding='utf-8') as f:
            existing = set(line.strip().lower() for line in f if line.strip())
            
    added = 0
    with open(target_file, 'a', encoding='utf-8') as f:
        for w in sorted(list(set(words))):
            w_clean = w.strip().lower()
            if w_clean and w_clean not in existing:
                f.write(w_clean + '\n')
                added += 1
                
    return jsonify({"success": True, "count": added, "target": target_id})

@app.route('/api/save_cache_bulk', methods=['POST'])
def save_cache_bulk():
    """Batch updates to the dictionary cache."""
    results = request.json # Expecting {word: result_obj, ...}
    if not results:
        return jsonify({"success": False}), 400
    save_dict_cache(results)
    return jsonify({"success": True})

@app.route('/api/sync_cache', methods=['POST'])
def sync_cache():
    """
    Scans the dictionary_cache.json and moves all 'is_known' words 
    to their respective local storage TXT files.
    """
    cache = load_dict_cache()
    stats = {}
    total_added = 0

    # Group words by source from the cache
    for word, res in cache.items():
        if res.get('is_known'):
            source_id = res.get('source')
            if not source_id: continue
            
            # Find the save file for this source
            target_file = None
            for src in VALIDATION_SOURCES:
                if src['id'] == source_id:
                    target_file = src['save_file']
                    break
            
            if target_file:
                if target_file not in stats:
                    stats[target_file] = []
                stats[target_file].append(word)

    # Perform the updates
    results = []
    for target_file, words in stats.items():
        existing = set()
        if os.path.exists(target_file):
            with open(target_file, 'r', encoding='utf-8') as f:
                existing = set(line.strip().lower() for line in f if line.strip())
        
        added_to_this = 0
        with open(target_file, 'a', encoding='utf-8') as f:
            for w in sorted(list(set(words))):
                w_clean = w.strip().lower()
                if w_clean and w_clean not in existing:
                    f.write(w_clean + '\n')
                    added_to_this += 1
                    total_added += 1
        
        # Get purely descriptive filename for results
        fname = os.path.basename(target_file)
        results.append({"file": fname, "added": added_to_this})

    return jsonify({"success": True, "total_added": total_added, "details": results})

@app.route('/save_words', methods=['POST'])
def save_words():
    words_to_add = request.form.getlist('words_to_add')
    target = request.form.get('target', 'custom') # 'common' or 'custom'
    
    if not words_to_add:
        return redirect(url_for('index'))
    
    target_file = COMMON_WORDS_FILE if target == 'common' else CUSTOM_WORDS_FILE
    
    existing = set()
    if os.path.exists(target_file):
        with open(target_file, 'r', encoding='utf-8') as f:
            existing = set(line.strip().lower() for line in f if line.strip())
            
    added_count = 0
    with open(target_file, 'a', encoding='utf-8') as f:
        for word in words_to_add:
            w_lower = word.lower()
            if w_lower not in existing:
                f.write(w_lower + '\n')
                existing.add(w_lower)
                added_count += 1
                
    return render_template('harvest_success.html', count=added_count, target=target)

@app.route('/api/check_word', methods=['GET'])
def api_check_word():
    word = request.args.get('word', '').strip().lower()
    if not word:
        return {"error": "No word provided"}, 400
    
    existing = load_common_words()
    is_common = word in existing
    
    return {
        "word": word,
        "is_common": is_common,
        "status": "found" if is_common else "not_found"
    }

if __name__ == '__main__':
    app.run(debug=True, port=5000)
